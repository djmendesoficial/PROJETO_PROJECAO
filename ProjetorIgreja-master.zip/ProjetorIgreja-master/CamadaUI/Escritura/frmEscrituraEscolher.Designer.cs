﻿namespace CamadaUI.Escritura
{
	partial class frmEscrituraEscolher
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pnlAT = new System.Windows.Forms.Panel();
			this.line5 = new AwesomeShapeControl.Line();
			this.line4 = new AwesomeShapeControl.Line();
			this.line3 = new AwesomeShapeControl.Line();
			this.line1 = new AwesomeShapeControl.Line();
			this.line2 = new AwesomeShapeControl.Line();
			this.btnLivro33 = new System.Windows.Forms.Button();
			this.btnLivro25 = new System.Windows.Forms.Button();
			this.btnLivro16 = new System.Windows.Forms.Button();
			this.btnLivro8 = new System.Windows.Forms.Button();
			this.btnLivro32 = new System.Windows.Forms.Button();
			this.btnLivro24 = new System.Windows.Forms.Button();
			this.btnLivro15 = new System.Windows.Forms.Button();
			this.btnLivro7 = new System.Windows.Forms.Button();
			this.btnLivro31 = new System.Windows.Forms.Button();
			this.btnLivro23 = new System.Windows.Forms.Button();
			this.btnLivro14 = new System.Windows.Forms.Button();
			this.btnLivro6 = new System.Windows.Forms.Button();
			this.btnLivro30 = new System.Windows.Forms.Button();
			this.btnLivro22 = new System.Windows.Forms.Button();
			this.btnLivro13 = new System.Windows.Forms.Button();
			this.btnLivro5 = new System.Windows.Forms.Button();
			this.btnLivro29 = new System.Windows.Forms.Button();
			this.btnLivro21 = new System.Windows.Forms.Button();
			this.btnLivro12 = new System.Windows.Forms.Button();
			this.btnLivro4 = new System.Windows.Forms.Button();
			this.btnLivro17 = new System.Windows.Forms.Button();
			this.btnLivro28 = new System.Windows.Forms.Button();
			this.btnLivro20 = new System.Windows.Forms.Button();
			this.btnLivro11 = new System.Windows.Forms.Button();
			this.btnLivro3 = new System.Windows.Forms.Button();
			this.btnLivro39 = new System.Windows.Forms.Button();
			this.btnLivro38 = new System.Windows.Forms.Button();
			this.btnLivro37 = new System.Windows.Forms.Button();
			this.btnLivro36 = new System.Windows.Forms.Button();
			this.btnLivro35 = new System.Windows.Forms.Button();
			this.btnLivro27 = new System.Windows.Forms.Button();
			this.btnLivro19 = new System.Windows.Forms.Button();
			this.btnLivro10 = new System.Windows.Forms.Button();
			this.btnLivro2 = new System.Windows.Forms.Button();
			this.btnLivro34 = new System.Windows.Forms.Button();
			this.btnLivro26 = new System.Windows.Forms.Button();
			this.btnLivro18 = new System.Windows.Forms.Button();
			this.btnLivro9 = new System.Windows.Forms.Button();
			this.btnLivro1 = new System.Windows.Forms.Button();
			this.btnAntigoTestamento = new Glass.GlassButton();
			this.btnNovoTestamento = new Glass.GlassButton();
			this.lblVersiculo = new System.Windows.Forms.Label();
			this.pnlNT = new System.Windows.Forms.Panel();
			this.line7 = new AwesomeShapeControl.Line();
			this.line8 = new AwesomeShapeControl.Line();
			this.line9 = new AwesomeShapeControl.Line();
			this.line10 = new AwesomeShapeControl.Line();
			this.btnLivro63 = new System.Windows.Forms.Button();
			this.btnLivro55 = new System.Windows.Forms.Button();
			this.btnLivro47 = new System.Windows.Forms.Button();
			this.btnLivro62 = new System.Windows.Forms.Button();
			this.btnLivro54 = new System.Windows.Forms.Button();
			this.btnLivro46 = new System.Windows.Forms.Button();
			this.btnLivro61 = new System.Windows.Forms.Button();
			this.btnLivro53 = new System.Windows.Forms.Button();
			this.btnLivro45 = new System.Windows.Forms.Button();
			this.btnLivro60 = new System.Windows.Forms.Button();
			this.btnLivro52 = new System.Windows.Forms.Button();
			this.btnLivro44 = new System.Windows.Forms.Button();
			this.btnLivro59 = new System.Windows.Forms.Button();
			this.btnLivro51 = new System.Windows.Forms.Button();
			this.btnLivro43 = new System.Windows.Forms.Button();
			this.btnLivro66 = new System.Windows.Forms.Button();
			this.btnLivro58 = new System.Windows.Forms.Button();
			this.btnLivro50 = new System.Windows.Forms.Button();
			this.btnLivro42 = new System.Windows.Forms.Button();
			this.btnLivro65 = new System.Windows.Forms.Button();
			this.btnLivro57 = new System.Windows.Forms.Button();
			this.btnLivro49 = new System.Windows.Forms.Button();
			this.btnLivro41 = new System.Windows.Forms.Button();
			this.btnLivro64 = new System.Windows.Forms.Button();
			this.btnLivro56 = new System.Windows.Forms.Button();
			this.btnLivro48 = new System.Windows.Forms.Button();
			this.btnLivro40 = new System.Windows.Forms.Button();
			this.pnlCapitulosItems = new System.Windows.Forms.FlowLayoutPanel();
			this.btnCap1 = new System.Windows.Forms.Button();
			this.pnlCapitulos = new System.Windows.Forms.Panel();
			this.lblPanelCapTitulo = new System.Windows.Forms.Label();
			this.btnVoltar = new Glass.GlassButton();
			this.panel1.SuspendLayout();
			this.pnlAT.SuspendLayout();
			this.pnlNT.SuspendLayout();
			this.pnlCapitulosItems.SuspendLayout();
			this.pnlCapitulos.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.Location = new System.Drawing.Point(828, 0);
			this.lblTitulo.Size = new System.Drawing.Size(218, 50);
			this.lblTitulo.Text = "Escolher Versículo";
			// 
			// btnClose
			// 
			this.btnClose.FlatAppearance.BorderSize = 0;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGoldenrodYellow;
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Firebrick;
			this.btnClose.Location = new System.Drawing.Point(1046, 0);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// panel1
			// 
			this.panel1.Size = new System.Drawing.Size(1086, 50);
			// 
			// pnlAT
			// 
			this.pnlAT.BackColor = System.Drawing.Color.White;
			this.pnlAT.Controls.Add(this.line5);
			this.pnlAT.Controls.Add(this.line4);
			this.pnlAT.Controls.Add(this.line3);
			this.pnlAT.Controls.Add(this.line1);
			this.pnlAT.Controls.Add(this.line2);
			this.pnlAT.Controls.Add(this.btnLivro33);
			this.pnlAT.Controls.Add(this.btnLivro25);
			this.pnlAT.Controls.Add(this.btnLivro16);
			this.pnlAT.Controls.Add(this.btnLivro8);
			this.pnlAT.Controls.Add(this.btnLivro32);
			this.pnlAT.Controls.Add(this.btnLivro24);
			this.pnlAT.Controls.Add(this.btnLivro15);
			this.pnlAT.Controls.Add(this.btnLivro7);
			this.pnlAT.Controls.Add(this.btnLivro31);
			this.pnlAT.Controls.Add(this.btnLivro23);
			this.pnlAT.Controls.Add(this.btnLivro14);
			this.pnlAT.Controls.Add(this.btnLivro6);
			this.pnlAT.Controls.Add(this.btnLivro30);
			this.pnlAT.Controls.Add(this.btnLivro22);
			this.pnlAT.Controls.Add(this.btnLivro13);
			this.pnlAT.Controls.Add(this.btnLivro5);
			this.pnlAT.Controls.Add(this.btnLivro29);
			this.pnlAT.Controls.Add(this.btnLivro21);
			this.pnlAT.Controls.Add(this.btnLivro12);
			this.pnlAT.Controls.Add(this.btnLivro4);
			this.pnlAT.Controls.Add(this.btnLivro17);
			this.pnlAT.Controls.Add(this.btnLivro28);
			this.pnlAT.Controls.Add(this.btnLivro20);
			this.pnlAT.Controls.Add(this.btnLivro11);
			this.pnlAT.Controls.Add(this.btnLivro3);
			this.pnlAT.Controls.Add(this.btnLivro39);
			this.pnlAT.Controls.Add(this.btnLivro38);
			this.pnlAT.Controls.Add(this.btnLivro37);
			this.pnlAT.Controls.Add(this.btnLivro36);
			this.pnlAT.Controls.Add(this.btnLivro35);
			this.pnlAT.Controls.Add(this.btnLivro27);
			this.pnlAT.Controls.Add(this.btnLivro19);
			this.pnlAT.Controls.Add(this.btnLivro10);
			this.pnlAT.Controls.Add(this.btnLivro2);
			this.pnlAT.Controls.Add(this.btnLivro34);
			this.pnlAT.Controls.Add(this.btnLivro26);
			this.pnlAT.Controls.Add(this.btnLivro18);
			this.pnlAT.Controls.Add(this.btnLivro9);
			this.pnlAT.Controls.Add(this.btnLivro1);
			this.pnlAT.Location = new System.Drawing.Point(19, 121);
			this.pnlAT.Name = "pnlAT";
			this.pnlAT.Size = new System.Drawing.Size(1046, 484);
			this.pnlAT.TabIndex = 1;
			// 
			// line5
			// 
			this.line5.EndPoint = new System.Drawing.Point(5, 450);
			this.line5.LineColor = System.Drawing.Color.LightSlateGray;
			this.line5.LineWidth = 5F;
			this.line5.Location = new System.Drawing.Point(832, 13);
			this.line5.Name = "line5";
			this.line5.Opacity = 0.6F;
			this.line5.Size = new System.Drawing.Size(10, 455);
			this.line5.StartPoint = new System.Drawing.Point(5, 5);
			this.line5.TabIndex = 54;
			this.line5.TabStop = false;
			// 
			// line4
			// 
			this.line4.EndPoint = new System.Drawing.Point(5, 450);
			this.line4.LineColor = System.Drawing.Color.LightSlateGray;
			this.line4.LineWidth = 5F;
			this.line4.Location = new System.Drawing.Point(628, 13);
			this.line4.Name = "line4";
			this.line4.Opacity = 0.6F;
			this.line4.Size = new System.Drawing.Size(10, 455);
			this.line4.StartPoint = new System.Drawing.Point(5, 5);
			this.line4.TabIndex = 53;
			this.line4.TabStop = false;
			// 
			// line3
			// 
			this.line3.EndPoint = new System.Drawing.Point(5, 450);
			this.line3.LineColor = System.Drawing.Color.LightSlateGray;
			this.line3.LineWidth = 5F;
			this.line3.Location = new System.Drawing.Point(420, 13);
			this.line3.Name = "line3";
			this.line3.Opacity = 0.6F;
			this.line3.Size = new System.Drawing.Size(10, 455);
			this.line3.StartPoint = new System.Drawing.Point(5, 5);
			this.line3.TabIndex = 52;
			this.line3.TabStop = false;
			// 
			// line1
			// 
			this.line1.EndPoint = new System.Drawing.Point(5, 450);
			this.line1.LineColor = System.Drawing.Color.LightSlateGray;
			this.line1.LineWidth = 5F;
			this.line1.Location = new System.Drawing.Point(212, 13);
			this.line1.Name = "line1";
			this.line1.Opacity = 0.6F;
			this.line1.Size = new System.Drawing.Size(10, 455);
			this.line1.StartPoint = new System.Drawing.Point(5, 5);
			this.line1.TabIndex = 51;
			this.line1.TabStop = false;
			// 
			// line2
			// 
			this.line2.EndPoint = new System.Drawing.Point(5, 450);
			this.line2.LineColor = System.Drawing.Color.LightSlateGray;
			this.line2.LineWidth = 5F;
			this.line2.Location = new System.Drawing.Point(9, 13);
			this.line2.Name = "line2";
			this.line2.Opacity = 0.6F;
			this.line2.Size = new System.Drawing.Size(10, 455);
			this.line2.StartPoint = new System.Drawing.Point(5, 5);
			this.line2.TabIndex = 50;
			this.line2.TabStop = false;
			// 
			// btnLivro33
			// 
			this.btnLivro33.FlatAppearance.BorderSize = 0;
			this.btnLivro33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro33.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro33.Location = new System.Drawing.Point(644, 319);
			this.btnLivro33.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro33.Name = "btnLivro33";
			this.btnLivro33.Size = new System.Drawing.Size(184, 45);
			this.btnLivro33.TabIndex = 33;
			this.btnLivro33.Text = "Miquéias";
			this.btnLivro33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro33.UseVisualStyleBackColor = true;
			this.btnLivro33.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro25
			// 
			this.btnLivro25.FlatAppearance.BorderSize = 0;
			this.btnLivro25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro25.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro25.Location = new System.Drawing.Point(438, 370);
			this.btnLivro25.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro25.Name = "btnLivro25";
			this.btnLivro25.Size = new System.Drawing.Size(184, 45);
			this.btnLivro25.TabIndex = 25;
			this.btnLivro25.Text = "Lamentações";
			this.btnLivro25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro25.UseVisualStyleBackColor = true;
			this.btnLivro25.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro16
			// 
			this.btnLivro16.FlatAppearance.BorderSize = 0;
			this.btnLivro16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro16.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro16.Location = new System.Drawing.Point(228, 370);
			this.btnLivro16.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro16.Name = "btnLivro16";
			this.btnLivro16.Size = new System.Drawing.Size(184, 45);
			this.btnLivro16.TabIndex = 16;
			this.btnLivro16.Text = "Neemias";
			this.btnLivro16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro16.UseVisualStyleBackColor = true;
			this.btnLivro16.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro8
			// 
			this.btnLivro8.FlatAppearance.BorderSize = 0;
			this.btnLivro8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro8.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro8.Location = new System.Drawing.Point(22, 370);
			this.btnLivro8.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro8.Name = "btnLivro8";
			this.btnLivro8.Size = new System.Drawing.Size(184, 45);
			this.btnLivro8.TabIndex = 8;
			this.btnLivro8.Text = "Rute";
			this.btnLivro8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro8.UseVisualStyleBackColor = true;
			this.btnLivro8.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro32
			// 
			this.btnLivro32.FlatAppearance.BorderSize = 0;
			this.btnLivro32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro32.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro32.Location = new System.Drawing.Point(644, 268);
			this.btnLivro32.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro32.Name = "btnLivro32";
			this.btnLivro32.Size = new System.Drawing.Size(184, 45);
			this.btnLivro32.TabIndex = 32;
			this.btnLivro32.Text = "Jonas";
			this.btnLivro32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro32.UseVisualStyleBackColor = true;
			this.btnLivro32.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro24
			// 
			this.btnLivro24.FlatAppearance.BorderSize = 0;
			this.btnLivro24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro24.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro24.Location = new System.Drawing.Point(438, 319);
			this.btnLivro24.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro24.Name = "btnLivro24";
			this.btnLivro24.Size = new System.Drawing.Size(184, 45);
			this.btnLivro24.TabIndex = 24;
			this.btnLivro24.Text = "Jeremias";
			this.btnLivro24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro24.UseVisualStyleBackColor = true;
			this.btnLivro24.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro15
			// 
			this.btnLivro15.FlatAppearance.BorderSize = 0;
			this.btnLivro15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro15.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro15.Location = new System.Drawing.Point(228, 319);
			this.btnLivro15.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro15.Name = "btnLivro15";
			this.btnLivro15.Size = new System.Drawing.Size(184, 45);
			this.btnLivro15.TabIndex = 15;
			this.btnLivro15.Text = "Esdras";
			this.btnLivro15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro15.UseVisualStyleBackColor = true;
			this.btnLivro15.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro7
			// 
			this.btnLivro7.FlatAppearance.BorderSize = 0;
			this.btnLivro7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro7.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro7.Location = new System.Drawing.Point(22, 319);
			this.btnLivro7.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro7.Name = "btnLivro7";
			this.btnLivro7.Size = new System.Drawing.Size(184, 45);
			this.btnLivro7.TabIndex = 7;
			this.btnLivro7.Text = "Juízes";
			this.btnLivro7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro7.UseVisualStyleBackColor = true;
			this.btnLivro7.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro31
			// 
			this.btnLivro31.FlatAppearance.BorderSize = 0;
			this.btnLivro31.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro31.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro31.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro31.Location = new System.Drawing.Point(644, 217);
			this.btnLivro31.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro31.Name = "btnLivro31";
			this.btnLivro31.Size = new System.Drawing.Size(184, 45);
			this.btnLivro31.TabIndex = 31;
			this.btnLivro31.Text = "Obadias";
			this.btnLivro31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro31.UseVisualStyleBackColor = true;
			this.btnLivro31.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro23
			// 
			this.btnLivro23.FlatAppearance.BorderSize = 0;
			this.btnLivro23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro23.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro23.Location = new System.Drawing.Point(438, 268);
			this.btnLivro23.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro23.Name = "btnLivro23";
			this.btnLivro23.Size = new System.Drawing.Size(184, 45);
			this.btnLivro23.TabIndex = 23;
			this.btnLivro23.Text = "Isaías";
			this.btnLivro23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro23.UseVisualStyleBackColor = true;
			this.btnLivro23.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro14
			// 
			this.btnLivro14.FlatAppearance.BorderSize = 0;
			this.btnLivro14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro14.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro14.Location = new System.Drawing.Point(228, 268);
			this.btnLivro14.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro14.Name = "btnLivro14";
			this.btnLivro14.Size = new System.Drawing.Size(184, 45);
			this.btnLivro14.TabIndex = 14;
			this.btnLivro14.Text = "II Crônicas";
			this.btnLivro14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro14.UseVisualStyleBackColor = true;
			this.btnLivro14.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro6
			// 
			this.btnLivro6.FlatAppearance.BorderSize = 0;
			this.btnLivro6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro6.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro6.Location = new System.Drawing.Point(22, 268);
			this.btnLivro6.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro6.Name = "btnLivro6";
			this.btnLivro6.Size = new System.Drawing.Size(184, 45);
			this.btnLivro6.TabIndex = 6;
			this.btnLivro6.Text = "Josué";
			this.btnLivro6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro6.UseVisualStyleBackColor = true;
			this.btnLivro6.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro30
			// 
			this.btnLivro30.FlatAppearance.BorderSize = 0;
			this.btnLivro30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro30.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro30.Location = new System.Drawing.Point(644, 166);
			this.btnLivro30.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro30.Name = "btnLivro30";
			this.btnLivro30.Size = new System.Drawing.Size(184, 45);
			this.btnLivro30.TabIndex = 30;
			this.btnLivro30.Text = "Omós";
			this.btnLivro30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro30.UseVisualStyleBackColor = true;
			this.btnLivro30.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro22
			// 
			this.btnLivro22.FlatAppearance.BorderSize = 0;
			this.btnLivro22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro22.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro22.Location = new System.Drawing.Point(438, 217);
			this.btnLivro22.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro22.Name = "btnLivro22";
			this.btnLivro22.Size = new System.Drawing.Size(184, 45);
			this.btnLivro22.TabIndex = 22;
			this.btnLivro22.Text = "Cantares";
			this.btnLivro22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro22.UseVisualStyleBackColor = true;
			this.btnLivro22.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro13
			// 
			this.btnLivro13.FlatAppearance.BorderSize = 0;
			this.btnLivro13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro13.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro13.Location = new System.Drawing.Point(228, 217);
			this.btnLivro13.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro13.Name = "btnLivro13";
			this.btnLivro13.Size = new System.Drawing.Size(184, 45);
			this.btnLivro13.TabIndex = 13;
			this.btnLivro13.Text = "I Crônicas";
			this.btnLivro13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro13.UseVisualStyleBackColor = true;
			this.btnLivro13.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro5
			// 
			this.btnLivro5.FlatAppearance.BorderSize = 0;
			this.btnLivro5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro5.Location = new System.Drawing.Point(22, 217);
			this.btnLivro5.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro5.Name = "btnLivro5";
			this.btnLivro5.Size = new System.Drawing.Size(184, 45);
			this.btnLivro5.TabIndex = 5;
			this.btnLivro5.Text = "Deuteronômio";
			this.btnLivro5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro5.UseVisualStyleBackColor = true;
			this.btnLivro5.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro29
			// 
			this.btnLivro29.FlatAppearance.BorderSize = 0;
			this.btnLivro29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro29.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro29.Location = new System.Drawing.Point(644, 115);
			this.btnLivro29.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro29.Name = "btnLivro29";
			this.btnLivro29.Size = new System.Drawing.Size(184, 45);
			this.btnLivro29.TabIndex = 29;
			this.btnLivro29.Text = "Joel";
			this.btnLivro29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro29.UseVisualStyleBackColor = true;
			this.btnLivro29.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro21
			// 
			this.btnLivro21.FlatAppearance.BorderSize = 0;
			this.btnLivro21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro21.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro21.Location = new System.Drawing.Point(438, 166);
			this.btnLivro21.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro21.Name = "btnLivro21";
			this.btnLivro21.Size = new System.Drawing.Size(184, 45);
			this.btnLivro21.TabIndex = 21;
			this.btnLivro21.Text = "Eclesiastes";
			this.btnLivro21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro21.UseVisualStyleBackColor = true;
			this.btnLivro21.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro12
			// 
			this.btnLivro12.FlatAppearance.BorderSize = 0;
			this.btnLivro12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro12.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro12.Location = new System.Drawing.Point(228, 166);
			this.btnLivro12.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro12.Name = "btnLivro12";
			this.btnLivro12.Size = new System.Drawing.Size(184, 45);
			this.btnLivro12.TabIndex = 12;
			this.btnLivro12.Text = "II Reis";
			this.btnLivro12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro12.UseVisualStyleBackColor = true;
			this.btnLivro12.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro4
			// 
			this.btnLivro4.FlatAppearance.BorderSize = 0;
			this.btnLivro4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro4.Location = new System.Drawing.Point(22, 166);
			this.btnLivro4.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro4.Name = "btnLivro4";
			this.btnLivro4.Size = new System.Drawing.Size(184, 45);
			this.btnLivro4.TabIndex = 4;
			this.btnLivro4.Text = "Números";
			this.btnLivro4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro4.UseVisualStyleBackColor = true;
			this.btnLivro4.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro17
			// 
			this.btnLivro17.FlatAppearance.BorderSize = 0;
			this.btnLivro17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro17.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro17.Location = new System.Drawing.Point(228, 421);
			this.btnLivro17.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro17.Name = "btnLivro17";
			this.btnLivro17.Size = new System.Drawing.Size(184, 45);
			this.btnLivro17.TabIndex = 17;
			this.btnLivro17.Text = "Ester";
			this.btnLivro17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro17.UseVisualStyleBackColor = true;
			this.btnLivro17.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro28
			// 
			this.btnLivro28.FlatAppearance.BorderSize = 0;
			this.btnLivro28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro28.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro28.Location = new System.Drawing.Point(644, 64);
			this.btnLivro28.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro28.Name = "btnLivro28";
			this.btnLivro28.Size = new System.Drawing.Size(184, 45);
			this.btnLivro28.TabIndex = 28;
			this.btnLivro28.Text = "Oséias";
			this.btnLivro28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro28.UseVisualStyleBackColor = true;
			this.btnLivro28.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro20
			// 
			this.btnLivro20.FlatAppearance.BorderSize = 0;
			this.btnLivro20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro20.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro20.Location = new System.Drawing.Point(438, 115);
			this.btnLivro20.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro20.Name = "btnLivro20";
			this.btnLivro20.Size = new System.Drawing.Size(184, 45);
			this.btnLivro20.TabIndex = 20;
			this.btnLivro20.Text = "Provérbios";
			this.btnLivro20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro20.UseVisualStyleBackColor = true;
			this.btnLivro20.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro11
			// 
			this.btnLivro11.FlatAppearance.BorderSize = 0;
			this.btnLivro11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro11.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro11.Location = new System.Drawing.Point(228, 115);
			this.btnLivro11.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro11.Name = "btnLivro11";
			this.btnLivro11.Size = new System.Drawing.Size(184, 45);
			this.btnLivro11.TabIndex = 11;
			this.btnLivro11.Text = "I Reis";
			this.btnLivro11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro11.UseVisualStyleBackColor = true;
			this.btnLivro11.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro3
			// 
			this.btnLivro3.FlatAppearance.BorderSize = 0;
			this.btnLivro3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro3.Location = new System.Drawing.Point(22, 115);
			this.btnLivro3.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro3.Name = "btnLivro3";
			this.btnLivro3.Size = new System.Drawing.Size(184, 45);
			this.btnLivro3.TabIndex = 3;
			this.btnLivro3.Text = "Levítico";
			this.btnLivro3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro3.UseVisualStyleBackColor = true;
			this.btnLivro3.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro39
			// 
			this.btnLivro39.FlatAppearance.BorderSize = 0;
			this.btnLivro39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro39.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro39.Location = new System.Drawing.Point(846, 166);
			this.btnLivro39.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro39.Name = "btnLivro39";
			this.btnLivro39.Size = new System.Drawing.Size(184, 45);
			this.btnLivro39.TabIndex = 39;
			this.btnLivro39.Text = "Malaquias";
			this.btnLivro39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro39.UseVisualStyleBackColor = true;
			this.btnLivro39.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro38
			// 
			this.btnLivro38.FlatAppearance.BorderSize = 0;
			this.btnLivro38.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro38.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro38.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro38.Location = new System.Drawing.Point(846, 115);
			this.btnLivro38.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro38.Name = "btnLivro38";
			this.btnLivro38.Size = new System.Drawing.Size(184, 45);
			this.btnLivro38.TabIndex = 38;
			this.btnLivro38.Text = "Zacarias";
			this.btnLivro38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro38.UseVisualStyleBackColor = true;
			this.btnLivro38.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro37
			// 
			this.btnLivro37.FlatAppearance.BorderSize = 0;
			this.btnLivro37.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro37.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro37.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro37.Location = new System.Drawing.Point(846, 64);
			this.btnLivro37.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro37.Name = "btnLivro37";
			this.btnLivro37.Size = new System.Drawing.Size(184, 45);
			this.btnLivro37.TabIndex = 37;
			this.btnLivro37.Text = "Ageu";
			this.btnLivro37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro37.UseVisualStyleBackColor = true;
			this.btnLivro37.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro36
			// 
			this.btnLivro36.FlatAppearance.BorderSize = 0;
			this.btnLivro36.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro36.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro36.Location = new System.Drawing.Point(846, 13);
			this.btnLivro36.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro36.Name = "btnLivro36";
			this.btnLivro36.Size = new System.Drawing.Size(184, 45);
			this.btnLivro36.TabIndex = 36;
			this.btnLivro36.Text = "Sofonias";
			this.btnLivro36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro36.UseVisualStyleBackColor = true;
			this.btnLivro36.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro35
			// 
			this.btnLivro35.FlatAppearance.BorderSize = 0;
			this.btnLivro35.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro35.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro35.Location = new System.Drawing.Point(644, 421);
			this.btnLivro35.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro35.Name = "btnLivro35";
			this.btnLivro35.Size = new System.Drawing.Size(184, 45);
			this.btnLivro35.TabIndex = 35;
			this.btnLivro35.Text = "Habacuque";
			this.btnLivro35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro35.UseVisualStyleBackColor = true;
			this.btnLivro35.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro27
			// 
			this.btnLivro27.FlatAppearance.BorderSize = 0;
			this.btnLivro27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro27.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro27.Location = new System.Drawing.Point(644, 13);
			this.btnLivro27.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro27.Name = "btnLivro27";
			this.btnLivro27.Size = new System.Drawing.Size(184, 45);
			this.btnLivro27.TabIndex = 27;
			this.btnLivro27.Text = "Daniel";
			this.btnLivro27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro27.UseVisualStyleBackColor = true;
			this.btnLivro27.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro19
			// 
			this.btnLivro19.BackColor = System.Drawing.Color.Transparent;
			this.btnLivro19.FlatAppearance.BorderSize = 0;
			this.btnLivro19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro19.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro19.Location = new System.Drawing.Point(438, 64);
			this.btnLivro19.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro19.Name = "btnLivro19";
			this.btnLivro19.Size = new System.Drawing.Size(184, 45);
			this.btnLivro19.TabIndex = 19;
			this.btnLivro19.Text = "Salmos";
			this.btnLivro19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro19.UseVisualStyleBackColor = false;
			this.btnLivro19.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro10
			// 
			this.btnLivro10.FlatAppearance.BorderSize = 0;
			this.btnLivro10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro10.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro10.Location = new System.Drawing.Point(228, 64);
			this.btnLivro10.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro10.Name = "btnLivro10";
			this.btnLivro10.Size = new System.Drawing.Size(184, 45);
			this.btnLivro10.TabIndex = 10;
			this.btnLivro10.Text = "II Samuel";
			this.btnLivro10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro10.UseVisualStyleBackColor = true;
			this.btnLivro10.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro2
			// 
			this.btnLivro2.FlatAppearance.BorderSize = 0;
			this.btnLivro2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro2.Location = new System.Drawing.Point(22, 64);
			this.btnLivro2.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro2.Name = "btnLivro2";
			this.btnLivro2.Size = new System.Drawing.Size(184, 45);
			this.btnLivro2.TabIndex = 2;
			this.btnLivro2.Text = "Êxodo";
			this.btnLivro2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro2.UseVisualStyleBackColor = true;
			this.btnLivro2.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro34
			// 
			this.btnLivro34.FlatAppearance.BorderSize = 0;
			this.btnLivro34.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro34.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro34.Location = new System.Drawing.Point(644, 370);
			this.btnLivro34.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro34.Name = "btnLivro34";
			this.btnLivro34.Size = new System.Drawing.Size(184, 45);
			this.btnLivro34.TabIndex = 34;
			this.btnLivro34.Text = "Naum";
			this.btnLivro34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro34.UseVisualStyleBackColor = true;
			this.btnLivro34.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro26
			// 
			this.btnLivro26.FlatAppearance.BorderSize = 0;
			this.btnLivro26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro26.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro26.Location = new System.Drawing.Point(438, 421);
			this.btnLivro26.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro26.Name = "btnLivro26";
			this.btnLivro26.Size = new System.Drawing.Size(184, 45);
			this.btnLivro26.TabIndex = 26;
			this.btnLivro26.Text = "Ezequiel";
			this.btnLivro26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro26.UseVisualStyleBackColor = true;
			this.btnLivro26.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro18
			// 
			this.btnLivro18.FlatAppearance.BorderSize = 0;
			this.btnLivro18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro18.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro18.Location = new System.Drawing.Point(438, 13);
			this.btnLivro18.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro18.Name = "btnLivro18";
			this.btnLivro18.Size = new System.Drawing.Size(184, 45);
			this.btnLivro18.TabIndex = 18;
			this.btnLivro18.Text = "Jó";
			this.btnLivro18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro18.UseVisualStyleBackColor = true;
			this.btnLivro18.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro9
			// 
			this.btnLivro9.FlatAppearance.BorderSize = 0;
			this.btnLivro9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro9.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro9.Location = new System.Drawing.Point(228, 13);
			this.btnLivro9.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro9.Name = "btnLivro9";
			this.btnLivro9.Size = new System.Drawing.Size(184, 45);
			this.btnLivro9.TabIndex = 9;
			this.btnLivro9.Text = "I Samuel";
			this.btnLivro9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro9.UseVisualStyleBackColor = true;
			this.btnLivro9.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro1
			// 
			this.btnLivro1.FlatAppearance.BorderSize = 0;
			this.btnLivro1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro1.Location = new System.Drawing.Point(22, 13);
			this.btnLivro1.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro1.Name = "btnLivro1";
			this.btnLivro1.Size = new System.Drawing.Size(184, 45);
			this.btnLivro1.TabIndex = 1;
			this.btnLivro1.Text = "Gênesis";
			this.btnLivro1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro1.UseVisualStyleBackColor = true;
			this.btnLivro1.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnAntigoTestamento
			// 
			this.btnAntigoTestamento.BackColor = System.Drawing.Color.SlateGray;
			this.btnAntigoTestamento.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAntigoTestamento.ForeColor = System.Drawing.Color.Black;
			this.btnAntigoTestamento.InnerBorderColor = System.Drawing.Color.SlateGray;
			this.btnAntigoTestamento.Location = new System.Drawing.Point(577, 61);
			this.btnAntigoTestamento.Name = "btnAntigoTestamento";
			this.btnAntigoTestamento.OuterBorderColor = System.Drawing.Color.Transparent;
			this.btnAntigoTestamento.ShineColor = System.Drawing.Color.Linen;
			this.btnAntigoTestamento.Size = new System.Drawing.Size(241, 49);
			this.btnAntigoTestamento.TabIndex = 3;
			this.btnAntigoTestamento.Text = "Antigo Testamento";
			this.btnAntigoTestamento.Click += new System.EventHandler(this.btnTestamento_Click);
			// 
			// btnNovoTestamento
			// 
			this.btnNovoTestamento.BackColor = System.Drawing.Color.LightGray;
			this.btnNovoTestamento.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
			this.btnNovoTestamento.ForeColor = System.Drawing.Color.DimGray;
			this.btnNovoTestamento.InnerBorderColor = System.Drawing.Color.DarkGray;
			this.btnNovoTestamento.Location = new System.Drawing.Point(824, 61);
			this.btnNovoTestamento.Name = "btnNovoTestamento";
			this.btnNovoTestamento.OuterBorderColor = System.Drawing.Color.Transparent;
			this.btnNovoTestamento.Size = new System.Drawing.Size(241, 49);
			this.btnNovoTestamento.TabIndex = 3;
			this.btnNovoTestamento.Text = "Novo Testamento";
			this.btnNovoTestamento.Click += new System.EventHandler(this.btnTestamento_Click);
			// 
			// lblVersiculo
			// 
			this.lblVersiculo.AutoSize = true;
			this.lblVersiculo.BackColor = System.Drawing.Color.Transparent;
			this.lblVersiculo.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVersiculo.Location = new System.Drawing.Point(80, 70);
			this.lblVersiculo.Name = "lblVersiculo";
			this.lblVersiculo.Size = new System.Drawing.Size(213, 29);
			this.lblVersiculo.TabIndex = 4;
			this.lblVersiculo.Text = "Escolha o Livro";
			// 
			// pnlNT
			// 
			this.pnlNT.BackColor = System.Drawing.Color.White;
			this.pnlNT.Controls.Add(this.line7);
			this.pnlNT.Controls.Add(this.line8);
			this.pnlNT.Controls.Add(this.line9);
			this.pnlNT.Controls.Add(this.line10);
			this.pnlNT.Controls.Add(this.btnLivro63);
			this.pnlNT.Controls.Add(this.btnLivro55);
			this.pnlNT.Controls.Add(this.btnLivro47);
			this.pnlNT.Controls.Add(this.btnLivro62);
			this.pnlNT.Controls.Add(this.btnLivro54);
			this.pnlNT.Controls.Add(this.btnLivro46);
			this.pnlNT.Controls.Add(this.btnLivro61);
			this.pnlNT.Controls.Add(this.btnLivro53);
			this.pnlNT.Controls.Add(this.btnLivro45);
			this.pnlNT.Controls.Add(this.btnLivro60);
			this.pnlNT.Controls.Add(this.btnLivro52);
			this.pnlNT.Controls.Add(this.btnLivro44);
			this.pnlNT.Controls.Add(this.btnLivro59);
			this.pnlNT.Controls.Add(this.btnLivro51);
			this.pnlNT.Controls.Add(this.btnLivro43);
			this.pnlNT.Controls.Add(this.btnLivro66);
			this.pnlNT.Controls.Add(this.btnLivro58);
			this.pnlNT.Controls.Add(this.btnLivro50);
			this.pnlNT.Controls.Add(this.btnLivro42);
			this.pnlNT.Controls.Add(this.btnLivro65);
			this.pnlNT.Controls.Add(this.btnLivro57);
			this.pnlNT.Controls.Add(this.btnLivro49);
			this.pnlNT.Controls.Add(this.btnLivro41);
			this.pnlNT.Controls.Add(this.btnLivro64);
			this.pnlNT.Controls.Add(this.btnLivro56);
			this.pnlNT.Controls.Add(this.btnLivro48);
			this.pnlNT.Controls.Add(this.btnLivro40);
			this.pnlNT.Location = new System.Drawing.Point(19, 121);
			this.pnlNT.Name = "pnlNT";
			this.pnlNT.Size = new System.Drawing.Size(1046, 443);
			this.pnlNT.TabIndex = 5;
			// 
			// line7
			// 
			this.line7.EndPoint = new System.Drawing.Point(5, 450);
			this.line7.LineColor = System.Drawing.Color.LightSlateGray;
			this.line7.LineWidth = 5F;
			this.line7.Location = new System.Drawing.Point(785, 13);
			this.line7.Name = "line7";
			this.line7.Opacity = 0.6F;
			this.line7.Size = new System.Drawing.Size(10, 410);
			this.line7.StartPoint = new System.Drawing.Point(5, 5);
			this.line7.TabIndex = 30;
			this.line7.TabStop = false;
			// 
			// line8
			// 
			this.line8.EndPoint = new System.Drawing.Point(5, 450);
			this.line8.LineColor = System.Drawing.Color.LightSlateGray;
			this.line8.LineWidth = 5F;
			this.line8.Location = new System.Drawing.Point(520, 13);
			this.line8.Name = "line8";
			this.line8.Opacity = 0.6F;
			this.line8.Size = new System.Drawing.Size(10, 410);
			this.line8.StartPoint = new System.Drawing.Point(5, 5);
			this.line8.TabIndex = 30;
			this.line8.TabStop = false;
			// 
			// line9
			// 
			this.line9.EndPoint = new System.Drawing.Point(5, 450);
			this.line9.LineColor = System.Drawing.Color.LightSlateGray;
			this.line9.LineWidth = 5F;
			this.line9.Location = new System.Drawing.Point(254, 13);
			this.line9.Name = "line9";
			this.line9.Opacity = 0.6F;
			this.line9.Size = new System.Drawing.Size(10, 410);
			this.line9.StartPoint = new System.Drawing.Point(5, 5);
			this.line9.TabIndex = 30;
			this.line9.TabStop = false;
			// 
			// line10
			// 
			this.line10.EndPoint = new System.Drawing.Point(5, 450);
			this.line10.LineColor = System.Drawing.Color.LightSlateGray;
			this.line10.LineWidth = 5F;
			this.line10.Location = new System.Drawing.Point(9, 13);
			this.line10.Name = "line10";
			this.line10.Opacity = 0.6F;
			this.line10.Size = new System.Drawing.Size(10, 410);
			this.line10.StartPoint = new System.Drawing.Point(5, 5);
			this.line10.TabIndex = 30;
			this.line10.TabStop = false;
			// 
			// btnLivro63
			// 
			this.btnLivro63.FlatAppearance.BorderSize = 0;
			this.btnLivro63.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro63.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro63.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro63.Location = new System.Drawing.Point(821, 64);
			this.btnLivro63.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro63.Name = "btnLivro63";
			this.btnLivro63.Size = new System.Drawing.Size(211, 45);
			this.btnLivro63.TabIndex = 24;
			this.btnLivro63.Text = "II João";
			this.btnLivro63.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro63.UseVisualStyleBackColor = true;
			this.btnLivro63.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro55
			// 
			this.btnLivro55.FlatAppearance.BorderSize = 0;
			this.btnLivro55.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro55.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro55.Location = new System.Drawing.Point(287, 370);
			this.btnLivro55.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro55.Name = "btnLivro55";
			this.btnLivro55.Size = new System.Drawing.Size(211, 45);
			this.btnLivro55.TabIndex = 16;
			this.btnLivro55.Text = "II Timóteo";
			this.btnLivro55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro55.UseVisualStyleBackColor = true;
			this.btnLivro55.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro47
			// 
			this.btnLivro47.FlatAppearance.BorderSize = 0;
			this.btnLivro47.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro47.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro47.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro47.Location = new System.Drawing.Point(22, 370);
			this.btnLivro47.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro47.Name = "btnLivro47";
			this.btnLivro47.Size = new System.Drawing.Size(211, 45);
			this.btnLivro47.TabIndex = 8;
			this.btnLivro47.Text = "II Coríntios";
			this.btnLivro47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro47.UseVisualStyleBackColor = true;
			this.btnLivro47.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro62
			// 
			this.btnLivro62.FlatAppearance.BorderSize = 0;
			this.btnLivro62.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro62.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro62.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro62.Location = new System.Drawing.Point(821, 13);
			this.btnLivro62.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro62.Name = "btnLivro62";
			this.btnLivro62.Size = new System.Drawing.Size(211, 45);
			this.btnLivro62.TabIndex = 23;
			this.btnLivro62.Text = "I João";
			this.btnLivro62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro62.UseVisualStyleBackColor = true;
			this.btnLivro62.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro54
			// 
			this.btnLivro54.FlatAppearance.BorderSize = 0;
			this.btnLivro54.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro54.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro54.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro54.Location = new System.Drawing.Point(287, 319);
			this.btnLivro54.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro54.Name = "btnLivro54";
			this.btnLivro54.Size = new System.Drawing.Size(211, 45);
			this.btnLivro54.TabIndex = 15;
			this.btnLivro54.Text = "I Timóteo";
			this.btnLivro54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro54.UseVisualStyleBackColor = true;
			this.btnLivro54.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro46
			// 
			this.btnLivro46.FlatAppearance.BorderSize = 0;
			this.btnLivro46.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro46.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro46.Location = new System.Drawing.Point(22, 319);
			this.btnLivro46.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro46.Name = "btnLivro46";
			this.btnLivro46.Size = new System.Drawing.Size(211, 45);
			this.btnLivro46.TabIndex = 7;
			this.btnLivro46.Text = "I Coríntios";
			this.btnLivro46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro46.UseVisualStyleBackColor = true;
			this.btnLivro46.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro61
			// 
			this.btnLivro61.FlatAppearance.BorderSize = 0;
			this.btnLivro61.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro61.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro61.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro61.Location = new System.Drawing.Point(559, 268);
			this.btnLivro61.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro61.Name = "btnLivro61";
			this.btnLivro61.Size = new System.Drawing.Size(211, 45);
			this.btnLivro61.TabIndex = 22;
			this.btnLivro61.Text = "II Pedro";
			this.btnLivro61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro61.UseVisualStyleBackColor = true;
			this.btnLivro61.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro53
			// 
			this.btnLivro53.FlatAppearance.BorderSize = 0;
			this.btnLivro53.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro53.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro53.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro53.Location = new System.Drawing.Point(287, 268);
			this.btnLivro53.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro53.Name = "btnLivro53";
			this.btnLivro53.Size = new System.Drawing.Size(211, 45);
			this.btnLivro53.TabIndex = 14;
			this.btnLivro53.Text = "II Tessalonicenses";
			this.btnLivro53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro53.UseVisualStyleBackColor = true;
			this.btnLivro53.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro45
			// 
			this.btnLivro45.FlatAppearance.BorderSize = 0;
			this.btnLivro45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro45.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro45.Location = new System.Drawing.Point(22, 268);
			this.btnLivro45.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro45.Name = "btnLivro45";
			this.btnLivro45.Size = new System.Drawing.Size(211, 45);
			this.btnLivro45.TabIndex = 6;
			this.btnLivro45.Text = "Romanos";
			this.btnLivro45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro45.UseVisualStyleBackColor = true;
			this.btnLivro45.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro60
			// 
			this.btnLivro60.FlatAppearance.BorderSize = 0;
			this.btnLivro60.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro60.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro60.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro60.Location = new System.Drawing.Point(559, 217);
			this.btnLivro60.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro60.Name = "btnLivro60";
			this.btnLivro60.Size = new System.Drawing.Size(211, 45);
			this.btnLivro60.TabIndex = 21;
			this.btnLivro60.Text = "I Pedro";
			this.btnLivro60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro60.UseVisualStyleBackColor = true;
			this.btnLivro60.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro52
			// 
			this.btnLivro52.FlatAppearance.BorderSize = 0;
			this.btnLivro52.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro52.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro52.Location = new System.Drawing.Point(287, 217);
			this.btnLivro52.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro52.Name = "btnLivro52";
			this.btnLivro52.Size = new System.Drawing.Size(211, 45);
			this.btnLivro52.TabIndex = 13;
			this.btnLivro52.Text = "I Tessalonicenses";
			this.btnLivro52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro52.UseVisualStyleBackColor = true;
			this.btnLivro52.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro44
			// 
			this.btnLivro44.FlatAppearance.BorderSize = 0;
			this.btnLivro44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro44.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro44.Location = new System.Drawing.Point(22, 217);
			this.btnLivro44.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro44.Name = "btnLivro44";
			this.btnLivro44.Size = new System.Drawing.Size(211, 45);
			this.btnLivro44.TabIndex = 5;
			this.btnLivro44.Text = "Atos dos Apóstolos";
			this.btnLivro44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro44.UseVisualStyleBackColor = true;
			this.btnLivro44.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro59
			// 
			this.btnLivro59.FlatAppearance.BorderSize = 0;
			this.btnLivro59.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro59.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro59.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro59.Location = new System.Drawing.Point(559, 166);
			this.btnLivro59.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro59.Name = "btnLivro59";
			this.btnLivro59.Size = new System.Drawing.Size(211, 45);
			this.btnLivro59.TabIndex = 20;
			this.btnLivro59.Text = "Tiago";
			this.btnLivro59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro59.UseVisualStyleBackColor = true;
			this.btnLivro59.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro51
			// 
			this.btnLivro51.FlatAppearance.BorderSize = 0;
			this.btnLivro51.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro51.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro51.Location = new System.Drawing.Point(287, 166);
			this.btnLivro51.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro51.Name = "btnLivro51";
			this.btnLivro51.Size = new System.Drawing.Size(211, 45);
			this.btnLivro51.TabIndex = 12;
			this.btnLivro51.Text = "Colossenses";
			this.btnLivro51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro51.UseVisualStyleBackColor = true;
			this.btnLivro51.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro43
			// 
			this.btnLivro43.FlatAppearance.BorderSize = 0;
			this.btnLivro43.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro43.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro43.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro43.Location = new System.Drawing.Point(22, 166);
			this.btnLivro43.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro43.Name = "btnLivro43";
			this.btnLivro43.Size = new System.Drawing.Size(211, 45);
			this.btnLivro43.TabIndex = 4;
			this.btnLivro43.Text = "João";
			this.btnLivro43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro43.UseVisualStyleBackColor = true;
			this.btnLivro43.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro66
			// 
			this.btnLivro66.FlatAppearance.BorderSize = 0;
			this.btnLivro66.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro66.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro66.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro66.Location = new System.Drawing.Point(821, 217);
			this.btnLivro66.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro66.Name = "btnLivro66";
			this.btnLivro66.Size = new System.Drawing.Size(211, 45);
			this.btnLivro66.TabIndex = 27;
			this.btnLivro66.Text = "Apocalipse";
			this.btnLivro66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro66.UseVisualStyleBackColor = true;
			this.btnLivro66.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro58
			// 
			this.btnLivro58.FlatAppearance.BorderSize = 0;
			this.btnLivro58.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro58.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro58.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro58.Location = new System.Drawing.Point(559, 115);
			this.btnLivro58.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro58.Name = "btnLivro58";
			this.btnLivro58.Size = new System.Drawing.Size(211, 45);
			this.btnLivro58.TabIndex = 19;
			this.btnLivro58.Text = "Hebreus";
			this.btnLivro58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro58.UseVisualStyleBackColor = true;
			this.btnLivro58.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro50
			// 
			this.btnLivro50.FlatAppearance.BorderSize = 0;
			this.btnLivro50.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro50.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro50.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro50.Location = new System.Drawing.Point(287, 115);
			this.btnLivro50.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro50.Name = "btnLivro50";
			this.btnLivro50.Size = new System.Drawing.Size(211, 45);
			this.btnLivro50.TabIndex = 11;
			this.btnLivro50.Text = "Filipenses";
			this.btnLivro50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro50.UseVisualStyleBackColor = true;
			this.btnLivro50.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro42
			// 
			this.btnLivro42.FlatAppearance.BorderSize = 0;
			this.btnLivro42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro42.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro42.Location = new System.Drawing.Point(22, 115);
			this.btnLivro42.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro42.Name = "btnLivro42";
			this.btnLivro42.Size = new System.Drawing.Size(211, 45);
			this.btnLivro42.TabIndex = 3;
			this.btnLivro42.Text = "Lucas";
			this.btnLivro42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro42.UseVisualStyleBackColor = true;
			this.btnLivro42.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro65
			// 
			this.btnLivro65.FlatAppearance.BorderSize = 0;
			this.btnLivro65.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro65.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro65.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro65.Location = new System.Drawing.Point(821, 166);
			this.btnLivro65.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro65.Name = "btnLivro65";
			this.btnLivro65.Size = new System.Drawing.Size(211, 45);
			this.btnLivro65.TabIndex = 26;
			this.btnLivro65.Text = "Judas";
			this.btnLivro65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro65.UseVisualStyleBackColor = true;
			this.btnLivro65.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro57
			// 
			this.btnLivro57.BackColor = System.Drawing.Color.Transparent;
			this.btnLivro57.FlatAppearance.BorderSize = 0;
			this.btnLivro57.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro57.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro57.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro57.Location = new System.Drawing.Point(559, 64);
			this.btnLivro57.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro57.Name = "btnLivro57";
			this.btnLivro57.Size = new System.Drawing.Size(211, 45);
			this.btnLivro57.TabIndex = 18;
			this.btnLivro57.Text = "Filemom";
			this.btnLivro57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro57.UseVisualStyleBackColor = false;
			this.btnLivro57.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro49
			// 
			this.btnLivro49.FlatAppearance.BorderSize = 0;
			this.btnLivro49.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro49.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro49.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro49.Location = new System.Drawing.Point(287, 64);
			this.btnLivro49.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro49.Name = "btnLivro49";
			this.btnLivro49.Size = new System.Drawing.Size(211, 45);
			this.btnLivro49.TabIndex = 10;
			this.btnLivro49.Text = "Efésios";
			this.btnLivro49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro49.UseVisualStyleBackColor = true;
			this.btnLivro49.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro41
			// 
			this.btnLivro41.FlatAppearance.BorderSize = 0;
			this.btnLivro41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro41.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro41.Location = new System.Drawing.Point(22, 64);
			this.btnLivro41.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro41.Name = "btnLivro41";
			this.btnLivro41.Size = new System.Drawing.Size(211, 45);
			this.btnLivro41.TabIndex = 2;
			this.btnLivro41.Text = "Marcos";
			this.btnLivro41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro41.UseVisualStyleBackColor = true;
			this.btnLivro41.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro64
			// 
			this.btnLivro64.FlatAppearance.BorderSize = 0;
			this.btnLivro64.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro64.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro64.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro64.Location = new System.Drawing.Point(821, 115);
			this.btnLivro64.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro64.Name = "btnLivro64";
			this.btnLivro64.Size = new System.Drawing.Size(211, 45);
			this.btnLivro64.TabIndex = 25;
			this.btnLivro64.Text = "III João";
			this.btnLivro64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro64.UseVisualStyleBackColor = true;
			this.btnLivro64.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro56
			// 
			this.btnLivro56.FlatAppearance.BorderSize = 0;
			this.btnLivro56.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro56.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro56.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro56.Location = new System.Drawing.Point(559, 13);
			this.btnLivro56.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro56.Name = "btnLivro56";
			this.btnLivro56.Size = new System.Drawing.Size(211, 45);
			this.btnLivro56.TabIndex = 17;
			this.btnLivro56.Text = "Tito";
			this.btnLivro56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro56.UseVisualStyleBackColor = true;
			this.btnLivro56.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro48
			// 
			this.btnLivro48.FlatAppearance.BorderSize = 0;
			this.btnLivro48.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro48.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro48.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro48.Location = new System.Drawing.Point(287, 13);
			this.btnLivro48.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro48.Name = "btnLivro48";
			this.btnLivro48.Size = new System.Drawing.Size(211, 45);
			this.btnLivro48.TabIndex = 9;
			this.btnLivro48.Text = "Gálatas";
			this.btnLivro48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro48.UseVisualStyleBackColor = true;
			this.btnLivro48.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// btnLivro40
			// 
			this.btnLivro40.FlatAppearance.BorderSize = 0;
			this.btnLivro40.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnLivro40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnLivro40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLivro40.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnLivro40.Location = new System.Drawing.Point(22, 13);
			this.btnLivro40.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnLivro40.Name = "btnLivro40";
			this.btnLivro40.Size = new System.Drawing.Size(211, 45);
			this.btnLivro40.TabIndex = 1;
			this.btnLivro40.Text = "Mateus";
			this.btnLivro40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnLivro40.UseVisualStyleBackColor = true;
			this.btnLivro40.Click += new System.EventHandler(this.btnLivro_Click);
			// 
			// pnlCapitulosItems
			// 
			this.pnlCapitulosItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlCapitulosItems.BackColor = System.Drawing.Color.Lavender;
			this.pnlCapitulosItems.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.pnlCapitulosItems.Controls.Add(this.btnCap1);
			this.pnlCapitulosItems.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
			this.pnlCapitulosItems.Location = new System.Drawing.Point(0, 41);
			this.pnlCapitulosItems.Name = "pnlCapitulosItems";
			this.pnlCapitulosItems.Size = new System.Drawing.Size(1002, 412);
			this.pnlCapitulosItems.TabIndex = 6;
			// 
			// btnCap1
			// 
			this.btnCap1.FlatAppearance.BorderSize = 0;
			this.btnCap1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Wheat;
			this.btnCap1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
			this.btnCap1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCap1.Font = new System.Drawing.Font("Geometr706 BlkCn BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCap1.Location = new System.Drawing.Point(11, 3);
			this.btnCap1.Margin = new System.Windows.Forms.Padding(11, 3, 11, 3);
			this.btnCap1.Name = "btnCap1";
			this.btnCap1.Size = new System.Drawing.Size(54, 30);
			this.btnCap1.TabIndex = 1;
			this.btnCap1.Text = "150";
			this.btnCap1.UseVisualStyleBackColor = true;
			this.btnCap1.Click += new System.EventHandler(this.btnCap_Click);
			// 
			// pnlCapitulos
			// 
			this.pnlCapitulos.Controls.Add(this.lblPanelCapTitulo);
			this.pnlCapitulos.Controls.Add(this.pnlCapitulosItems);
			this.pnlCapitulos.Location = new System.Drawing.Point(44, 134);
			this.pnlCapitulos.Name = "pnlCapitulos";
			this.pnlCapitulos.Size = new System.Drawing.Size(1002, 453);
			this.pnlCapitulos.TabIndex = 7;
			this.pnlCapitulos.Visible = false;
			// 
			// lblPanelCapTitulo
			// 
			this.lblPanelCapTitulo.AutoSize = true;
			this.lblPanelCapTitulo.BackColor = System.Drawing.Color.Transparent;
			this.lblPanelCapTitulo.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPanelCapTitulo.ForeColor = System.Drawing.Color.DimGray;
			this.lblPanelCapTitulo.Location = new System.Drawing.Point(6, 7);
			this.lblPanelCapTitulo.Name = "lblPanelCapTitulo";
			this.lblPanelCapTitulo.Size = new System.Drawing.Size(256, 29);
			this.lblPanelCapTitulo.TabIndex = 7;
			this.lblPanelCapTitulo.Text = "Escolha o Capítulo";
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.AliceBlue;
			this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
			this.btnVoltar.ForeColor = System.Drawing.Color.Black;
			this.btnVoltar.Image = global::CamadaUI.Properties.Resources.back;
			this.btnVoltar.InnerBorderColor = System.Drawing.Color.Transparent;
			this.btnVoltar.Location = new System.Drawing.Point(9, 61);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.OuterBorderColor = System.Drawing.Color.Transparent;
			this.btnVoltar.ShineColor = System.Drawing.Color.Linen;
			this.btnVoltar.Size = new System.Drawing.Size(65, 49);
			this.btnVoltar.TabIndex = 3;
			this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
			// 
			// frmEscrituraEscolher
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
			this.ClientSize = new System.Drawing.Size(1086, 621);
			this.Controls.Add(this.lblVersiculo);
			this.Controls.Add(this.btnNovoTestamento);
			this.Controls.Add(this.btnVoltar);
			this.Controls.Add(this.btnAntigoTestamento);
			this.Controls.Add(this.pnlCapitulos);
			this.Controls.Add(this.pnlAT);
			this.Controls.Add(this.pnlNT);
			this.KeyPreview = true;
			this.Name = "frmEscrituraEscolher";
			this.Activated += new System.EventHandler(this.frmEscrituraEscolher_Activated);
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmEscrituraEscolher_FormClosed);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmEscrituraEscolher_KeyDown);
			this.Controls.SetChildIndex(this.pnlNT, 0);
			this.Controls.SetChildIndex(this.pnlAT, 0);
			this.Controls.SetChildIndex(this.pnlCapitulos, 0);
			this.Controls.SetChildIndex(this.btnAntigoTestamento, 0);
			this.Controls.SetChildIndex(this.btnVoltar, 0);
			this.Controls.SetChildIndex(this.btnNovoTestamento, 0);
			this.Controls.SetChildIndex(this.lblVersiculo, 0);
			this.Controls.SetChildIndex(this.panel1, 0);
			this.panel1.ResumeLayout(false);
			this.pnlAT.ResumeLayout(false);
			this.pnlNT.ResumeLayout(false);
			this.pnlCapitulosItems.ResumeLayout(false);
			this.pnlCapitulos.ResumeLayout(false);
			this.pnlCapitulos.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel pnlAT;
		private System.Windows.Forms.Button btnLivro1;
		private System.Windows.Forms.Button btnLivro3;
		private System.Windows.Forms.Button btnLivro2;
		private System.Windows.Forms.Button btnLivro5;
		private System.Windows.Forms.Button btnLivro4;
		private Glass.GlassButton btnAntigoTestamento;
		private Glass.GlassButton btnNovoTestamento;
		private System.Windows.Forms.Button btnLivro8;
		private System.Windows.Forms.Button btnLivro7;
		private System.Windows.Forms.Button btnLivro6;
		private System.Windows.Forms.Button btnLivro33;
		private System.Windows.Forms.Button btnLivro25;
		private System.Windows.Forms.Button btnLivro16;
		private System.Windows.Forms.Button btnLivro32;
		private System.Windows.Forms.Button btnLivro24;
		private System.Windows.Forms.Button btnLivro15;
		private System.Windows.Forms.Button btnLivro31;
		private System.Windows.Forms.Button btnLivro23;
		private System.Windows.Forms.Button btnLivro14;
		private System.Windows.Forms.Button btnLivro30;
		private System.Windows.Forms.Button btnLivro22;
		private System.Windows.Forms.Button btnLivro13;
		private System.Windows.Forms.Button btnLivro29;
		private System.Windows.Forms.Button btnLivro21;
		private System.Windows.Forms.Button btnLivro12;
		private System.Windows.Forms.Button btnLivro17;
		private System.Windows.Forms.Button btnLivro28;
		private System.Windows.Forms.Button btnLivro20;
		private System.Windows.Forms.Button btnLivro11;
		private System.Windows.Forms.Button btnLivro35;
		private System.Windows.Forms.Button btnLivro27;
		private System.Windows.Forms.Button btnLivro19;
		private System.Windows.Forms.Button btnLivro10;
		private System.Windows.Forms.Button btnLivro34;
		private System.Windows.Forms.Button btnLivro26;
		private System.Windows.Forms.Button btnLivro18;
		private System.Windows.Forms.Button btnLivro9;
		private System.Windows.Forms.Button btnLivro39;
		private System.Windows.Forms.Button btnLivro38;
		private System.Windows.Forms.Button btnLivro37;
		private System.Windows.Forms.Button btnLivro36;
		private AwesomeShapeControl.Line line2;
		private AwesomeShapeControl.Line line3;
		private AwesomeShapeControl.Line line1;
		private AwesomeShapeControl.Line line5;
		private AwesomeShapeControl.Line line4;
		private System.Windows.Forms.Label lblVersiculo;
		private System.Windows.Forms.Panel pnlNT;
		private AwesomeShapeControl.Line line7;
		private AwesomeShapeControl.Line line8;
		private AwesomeShapeControl.Line line9;
		private AwesomeShapeControl.Line line10;
		private System.Windows.Forms.Button btnLivro63;
		private System.Windows.Forms.Button btnLivro55;
		private System.Windows.Forms.Button btnLivro47;
		private System.Windows.Forms.Button btnLivro62;
		private System.Windows.Forms.Button btnLivro54;
		private System.Windows.Forms.Button btnLivro46;
		private System.Windows.Forms.Button btnLivro61;
		private System.Windows.Forms.Button btnLivro53;
		private System.Windows.Forms.Button btnLivro45;
		private System.Windows.Forms.Button btnLivro60;
		private System.Windows.Forms.Button btnLivro52;
		private System.Windows.Forms.Button btnLivro44;
		private System.Windows.Forms.Button btnLivro59;
		private System.Windows.Forms.Button btnLivro51;
		private System.Windows.Forms.Button btnLivro43;
		private System.Windows.Forms.Button btnLivro66;
		private System.Windows.Forms.Button btnLivro58;
		private System.Windows.Forms.Button btnLivro50;
		private System.Windows.Forms.Button btnLivro42;
		private System.Windows.Forms.Button btnLivro65;
		private System.Windows.Forms.Button btnLivro57;
		private System.Windows.Forms.Button btnLivro49;
		private System.Windows.Forms.Button btnLivro41;
		private System.Windows.Forms.Button btnLivro64;
		private System.Windows.Forms.Button btnLivro56;
		private System.Windows.Forms.Button btnLivro48;
		private System.Windows.Forms.Button btnLivro40;
		private System.Windows.Forms.FlowLayoutPanel pnlCapitulosItems;
		private System.Windows.Forms.Button btnCap1;
		private System.Windows.Forms.Panel pnlCapitulos;
		private System.Windows.Forms.Label lblPanelCapTitulo;
		private Glass.GlassButton btnVoltar;
	}
}
