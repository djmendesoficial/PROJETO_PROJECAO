﻿namespace CamadaDTO
{
	public class clLinguagem
	{
		public int IDLinguagem { get; set; }
		public string Linguagem { get; set; }
		public string Sigla { get; set; }
	}
}
