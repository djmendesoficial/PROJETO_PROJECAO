﻿namespace CamadaDTO
{
	public class clLivro
	{
		public byte IDLivro { get; set; }
		public string Livro { get; set; }
		public string Abreviacao { get; set; }
		public byte Capitulos { get; set; }
	}
}
