DataShowIgreja
==============

Sistema que auxilia na proje��o com o datashow das letras de louvores na igreja.

M�sicas dispon�veis at� o momento (ordem alfab�tica pela primeira frase da m�sica)

a alegria,
abra os meus ouvidos,
abra os olhos,
abriu mao de sua gloria,
adoramos adoramos a Jesus,
agita as aguas,
alegrai-vos,
amado Jesus,
amor eterno,
amor tao grande,
ao contemplar,
ao que est� assentado,
ao unico,
digno de gl�ria,
eu te busco,
quando a noite fria cair sobre mim,




