# SiProIgre

SiProIgre - Sistema de Projeção de Igreja

Estágio Supervisionado 1.2018 - 5. Semestre (SIST5A)

Faculdade JK - Bacharelado em Sistemas de Informação

Tadeu Espíndola Palermo e Marcos Alexandre da Silva Lima