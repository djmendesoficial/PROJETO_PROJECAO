package br.com.tadeudeveloper.siproigre.dao;

public class LogDAO extends DAO {
	
	private static final long serialVersionUID = -6187066872296267351L;
	
}
