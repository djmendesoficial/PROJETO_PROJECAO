# Worship4J

Alguns anos atrás comecei a desenvolver esse sistema para auxiliar nas projeções da minha igreja, não consegui finalizar e decidimos por uma solução comercial.

Decidi então, disponibilizar o código para quem quiser usar, pode ser usado sem restrições e modificado.

# Funcionalidades

- Apresentar músicas
- Exibir Bíblias completas
- Exibir vídeos
- Preparar o cronograma do culto
- Exibir a logo da igreja, sobrepondo qualquer apresentação
- Exibir um fundo preto, sobrepondo qualquer apresentação 

# Como usar

Veja aqui: http://www.paulocollares.com.br/2019/04/worship4j-sistema-de-apresentacao-e-projecao-para-igrejas-gratuito-e-livre/
