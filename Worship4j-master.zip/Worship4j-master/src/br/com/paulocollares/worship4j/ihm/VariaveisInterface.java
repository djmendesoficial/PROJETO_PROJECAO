package br.com.paulocollares.worship4j.ihm;

/**
 * Worship4j - http://collares.net.br/worship4j/
 *
 * @author Paulo Collares
 */
public class VariaveisInterface {

    public static final String SPLASH = "ihm/cenas/Splash.fxml";

    public static final String TELA_PRINCIPAL = "ihm/cenas/TelaPrincipal.fxml";
    public static final String TELA_SECUNDARIA = "ihm/cenas/TelaSecundaria.fxml";

}
